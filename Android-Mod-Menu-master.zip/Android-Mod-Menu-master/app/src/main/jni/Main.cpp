/*
 * Credits:
 *
 * Octowolve - Mod menu: https://github.com/z3r0Sec/Substrate-Template-With-Mod-Menu
 * And hooking: https://github.com/z3r0Sec/Substrate-Hooking-Example
 * VanHoevenTR A.K.A Nixi: https://github.com/LGLTeam/VanHoevenTR_Android_Mod_Menu
 * MrIkso - Mod menu: https://github.com/MrIkso/FloatingModMenu
 * Rprop - https://github.com/Rprop/And64InlineHook
 * MJx0 A.K.A Ruit - KittyMemory: https://github.com/MJx0/KittyMemory
 * */
#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"
#include "Includes/Utils.h"
#include "Includes/obfuscate.h"

#include "Menu.h"

#include "Toast.h"

#if defined(__aarch64__) //Compile for arm64 lib only
#include <And64InlineHook/And64InlineHook.hpp>
#else //Compile for armv7 lib only. Do not worry about greyed out highlighting code, it still works

#include <Substrate/SubstrateHook.h>
#include <Substrate/CydiaSubstrate.h>

#endif

// fancy struct for patches for kittyMemory
struct My_Patches {
    // let's assume we have patches for these functions for whatever game
    // like show in miniMap boolean function
    MemoryPatch bypass,bypass2,bypass3,ls,cross,wh,aimlock,bd;
    // etc...
} hexPatches;

bool feature1 = false, feature2 = false, feature3 = false, feature4 = false, feature5 = false, feature6 = false, featureHookToggle = false;
void *instanceBtn;

// Function pointer splitted because we want to avoid crash when the il2cpp lib isn't loaded.
// If you putted getAbsoluteAddress here, the lib tries to read the address without il2cpp loaded,
// will result in a null pointer which will cause crash
// See https://guidedhacking.com/threads/android-function-pointers-hooking-template-tutorial.14771/
void (*AddMoneyExample)(void *instance, int amount);

//Target lib here
#define targetLibName OBFUSCATE("libUE4.so")

extern "C" {
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint feature, jint value, jboolean boolean, jstring str) {

    const char *featureName = env->GetStringUTFChars(str, 0);
    feature += 1;  // No need to count from 0 anymore. yaaay :)))

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d"), feature, featureName, value,
         boolean);

    //!!! BE CAREFUL NOT TO ACCIDENTLY REMOVE break; !!!//

//ini Biarin Aja
    if (feature == 1) {
        feature1 = boolean;
        if (feature1) {
            hexPatches.bypass.Modify();
            hexPatches.bypass2.Modify();

        } else {
            hexPatches.bypass.Restore();
            hexPatches.bypass2.Restore();
        }
    }

    else if (feature == 2) {
        feature2 = boolean;
        if (feature2) {
            hexPatches.ls.Modify();

        } else {
            hexPatches.ls.Restore();
        }
    }
    
    else if (feature == 3) {
        feature3 = boolean;
        if (feature3) {
            hexPatches.cross.Modify();

        } else {
            hexPatches.cross.Restore();
        }
    }
    
    else if (feature == 4) {
        feature4 = boolean;
        if (feature4) {
            hexPatches.wh.Modify();

        } else {
            hexPatches.wh.Restore();
        }
    }

    else if (feature == 5) {
        feature5 = boolean;
        if (feature5) {
            hexPatches.aimlock.Modify();

        } else {
            hexPatches.aimlock.Restore();
        }
    }

    else if (feature == 6) {
        feature6 = boolean;
        if (feature6) {
            hexPatches.bd.Modify();

        } else {
            hexPatches.bd.Restore();
        }
    }



}
}

// ---------- Hooking ---------- //

bool (*old_get_BoolExample)(void *instance);
bool get_BoolExample(void *instance) {
    if (instance != NULL && featureHookToggle) {
        return true;
    }
    return old_get_BoolExample(instance);
}
void (*old_Update)(void *instance);
void Update(void *instance) {
    instanceBtn = instance;
    old_Update(instance);
}

float (*old_get_FloatExample)(void *instance);

void *hack_thread(void *) {
	//ProcMap il2cppMap;
	ProcMap libtersafe;
	do {
		//il2cppMap = KittyMemory::getLibraryMap("libUE4.so");
		libtersafe = KittyMemory::getLibraryMap("libtersafe");
		sleep(1);
	} while(!libtersafe.isValid());
    sleep(1);

    //hexPatches.wh = MemoryPatch::createWithHex("libUE4.so", 0x2DD55C0, "E5 15 A0 E3");
    hexPatches.bypass = MemoryPatch::createWithHex("libUE4.so", 0x212D900, "00 00 A0 E3 1E FF 2F E1");
    hexPatches.bypass2 = MemoryPatch::createWithHex("libtersafe.so", 0x529368, "00 00 00 00 06 98 00 28");
    //hexPatches.bypass3 = MemoryPatch::createWithHex("libtersafe.so", 0x530780, "00 00 00 00 29 98 00 28");

    hexPatches.ls = MemoryPatch::createWithHex("libUE4.so", 0x130CAD4, "00 00 00 00");

    //hexPatches.nc = MemoryPatch::createWithHex("libUE4.so", 0x372D818, "00 00 00 00");
    //hexPatches.nc2 = MemoryPatch::createWithHex("libUE4.so", 0x367EC84, "00 00 00 00");

    hexPatches.cross = MemoryPatch::createWithHex("libUE4.so", 0x130D1A4, "00 00 00 00");
    
    hexPatches.wh = MemoryPatch::createWithHex("libUE4.so", 0x2DD55C0, "E5 15 A0 E3");

    //hexPatches.inshit = MemoryPatch::createWithHex("libUE4.so", 0x1D7EDB0, "99 F0 20 E3 1E FF 2F E1");

    //hexPatches.bt = MemoryPatch::createWithHex("libUE4.so", 0x3906258, "00 00 20 42");

    //hexPatches.mbvl = MemoryPatch::createWithHex("libUE4.so", 0x3B64788, "00 00 F0 41");
    //hexPatches.mbl = MemoryPatch::createWithHex("libUE4.so", 0x3B64788, "00 00 20 42");
    //hexPatches.mbm = MemoryPatch::createWithHex("libUE4.so", 0x3B64788, "00 00 48 42");
    //hexPatches.mbh = MemoryPatch::createWithHex("libUE4.so", 0x3B64788, "00 00 70 42");
    //hexPatches.mbvh = MemoryPatch::createWithHex("libUE4.so", 0x3B64788, "00 00 8C 42");

    //hexPatches.aimbot = MemoryPatch::createWithHex("libUE4.so", 0xFB4694, "00 00 00 00");
    //hexPatches.aimbot2 = MemoryPatch::createWithHex("libUE4.so", 0xFB2E54, "01 00 00 7A");
    //hexPatches.aimbot3 = MemoryPatch::createWithHex("libUE4.so", 0x24A74BC, "02 50 A0 E1");

    hexPatches.aimlock = MemoryPatch::createWithHex("libUE4.so", 0x24A74B0, "00 00 00 00");
    //hexPatches.aimlock2 = MemoryPatch::createWithHex("libUE4.so", 0x24A74BC, "00 00 00 00");

    //hexPatches.wd0 = MemoryPatch::createWithHex("libUE4.so", 0x37307E0, "00 00 B4 43");
    //hexPatches.wd1 = MemoryPatch::createWithHex("libUE4.so", 0x37307E0, "00 00 AA 43");
    //hexPatches.wd2 = MemoryPatch::createWithHex("libUE4.so", 0x37307E0, "00 00 A0 43");
    //hexPatches.wd3 = MemoryPatch::createWithHex("libUE4.so", 0x37307E0, "00 00 96 43");
    //hexPatches.wd4 = MemoryPatch::createWithHex("libUE4.so", 0x37307E0, "00 00 8C 43");
    //hexPatches.wd5 = MemoryPatch::createWithHex("libUE4.so", 0x37307E0, "00 00 82 43");
    //hexPatches.wd6 = MemoryPatch::createWithHex("libUE4.so", 0x37307E0, "00 00 70 43");
    //hexPatches.wd7 = MemoryPatch::createWithHex("libUE4.so", 0x37307E0, "00 00 5C 43");
    //hexPatches.wd8 = MemoryPatch::createWithHex("libUE4.so", 0x37307E0, "00 00 52 43");
    //hexPatches.wd9 = MemoryPatch::createWithHex("libUE4.so", 0x37307E0, "00 00 48 43");
    //hexPatches.wd10 = MemoryPatch::createWithHex("libUE4.so", 0x37307E0, "00 00 3E 43");

    //hexPatches.nofog = MemoryPatch::createWithHex("libUE4.so", 0x2C344C8, "00 00 00 00");

    hexPatches.bd = MemoryPatch::createWithHex("libUE4.so", 0x2CBD788, "00 00 60 41");

    //hexPatches.bs = MemoryPatch::createWithHex("libUE4.so", 0x3997244, "00 00 00 00");

    //hexPatches.dm = MemoryPatch::createWithHex("libUE4.so", 0x2E082FC, "41 2A B1 EE");

    //hexPatches.lj = MemoryPatch::createWithHex("libUE4.so", 0x1150134, "02 1A B7 EE");

    //hexPatches.flash = MemoryPatch::createWithHex("libUE4.so", 0x39D9D8C, "00 00 00 00");
    //hexPatches.flash2 = MemoryPatch::createWithHex("libUE4.so", 0x114FCE0, "00 00 00 00");

    //hexPatches.grass = MemoryPatch::createWithHex("libUE4.so", 0x2475D58, "00 00 00 00");




    /* hexPatches.Fiture4 = MemoryPatch::createWithHex("libUE4.so", 0x12281E4, "00 00 C0 41");

     hexPatches.Fiture5 = MemoryPatch::createWithHex("libUE4.so", 0x2125E0C, "00 00 00 00");
     hexPatches.Fiture6 = MemoryPatch::createWithHex("libUE4.so", 0x4BC0560, "00 00 00 00");
     hexPatches.Fiture7 = MemoryPatch::createWithHex("libUE4.so", 0x22BF3BC, "00 00 00 00");

     hexPatches.NotXColorsBlack = MemoryPatch::createWithHex("libUE4.so", 0x2ACCC28, "00 00 60 41");

     hexPatches.Fiture9 = MemoryPatch::createWithHex("libUE4.so", 0x2A43A18, "42 0A 30 EE");

     hexPatches.Fiture10= MemoryPatch::createWithHex("libUE4.so", 0x2BC492C, "00 00 00 00");



     hexPatches.wideview= MemoryPatch::createWithHex("libUE4.so", 0x34D7E30, "00 00 72 43");
     */


    return NULL;
}

__attribute__((constructor))
void lib_main() {
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
    pthread_t p;
    pthread_create(&p, NULL, antiLeech, NULL);
}
