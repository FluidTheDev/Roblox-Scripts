---
name: Bug report mod menu template
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

<!-- Replace the bracketed [...] placeholders with your own information. -->

### Describe the bug
<!-- [A clear and concise description of what the bug is.] -->

### Screenshot(s) or video
<!-- [If applicable, add screenshots or video to help explain your problem.] -->

### Logcat
<!-- [If menu crashes, put your logcat here] -->

```
Include logcat here
If the logcat is too long, please post on pastebin.com and link here instead
```
